
from js import Object

from pyodide.ffi import to_js

from .vec_js import vector_js as vector
from .vector import vector as vec_orig

vec = vector

from .vec_conversion import py2js_vec

# List of names that are exported imported from this module with import *
__all__ = ['convertPyVecsToJSList']

def convertPyVecsToJSList(pyVecList, root=True):
    result = []
    for item in pyVecList:
        if isinstance(item, list) or isinstance(item, tuple):
            result.append(convertPyVecsToJSList(item, root=False))
        elif isinstance(item, vector) or isinstance(item, vec_orig): # I don't think this should be neccessary, but Hmm....
            result.append(py2js_vec(item))
        else:
            result.append(item)
    if root:
        result = to_js(result, dict_converter=Object.fromEntries)
    return result

if 0:

    def roundc(cps, roundness=0.1, invert=False, nseg=16):
        """
        Round a list of control points. Then convert to js objects for extrusion
        """
        return to_js(roundc_orig(cps, roundness, invert, nseg))

    def rotatecp(cp, pos=[0,0], rotate=0):
        return to_js(rotatecp_orig(cp, pos, rotate))

    def scalecp(cp, xscale=1, yscale=1):
        return to_js(scalecp_orig(cp, xscale, yscale))

    def addpos(cp, pos=[0,0]):
        return to_js(addpos_orig(cp, pos))

    class shape_object(shape_object_orig):

        def rectangle(self, pos=[0,0], width=1, height=None, rotate=0, thickness=0,
                        roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.rectangle(shapes_orig, pos, width, height, rotate, thickness, roundness, invert, scale, xscale, yscale))

        def cross(self, pos=[0,0], width=1, rotate=0, thickness=0.2,
                    roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.cross(shapes_orig, pos, width, rotate, thickness, roundness, invert, scale, xscale, yscale))

        def trapezoid(self, pos=[0,0], width=2, height=1, top=None, rotate=0, thickness=0,
                    roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.trapezoid(shapes_orig, pos, width, height, top, rotate, thickness, roundness, invert, scale, xscale, yscale))

        def circle(self, pos=[0,0], radius=0.5, np=npdefault, rotate=0, thickness=0, corner=None, iradius=None,
                        angle1=0, angle2=2*pi, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.circle(shapes_orig, pos, radius, np, rotate, thickness, corner, iradius, angle1, angle2, scale, xscale, yscale))

        def arc(self, pos=[0,0], radius=0.5, np=npdefault, rotate=0, thickness=None,
                        angle1=0, angle2=2*pi, scale=1, xscale=1, yscale=1, path=False):
            return convertPyVecsToJSList(shape_object_orig.arc(shapes_orig, pos, radius, np, rotate, thickness, angle1, angle2, scale, xscale, yscale, path))

        def ellipse(self, pos=[0,0], width=1, height=None, np=npdefault, rotate=0, thickness=0,
                        angle1=0, angle2=2*pi, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.ellipse(shapes_orig, pos, width, height, np, rotate, thickness, angle1, angle2, scale, xscale, yscale))
        
        # line is not called by paths.
        def line(self, pos=[0,0], width=1, height=None, np=2, rotate=0, thickness=None,
                        start=[0,0], end=[0,1], scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.line(shapes_orig, pos, width, height, np, rotate, thickness, start, end, scale, xscale, yscale))

        def ngon(self, pos=[0,0], length=1, rotate=0, thickness=0, np=None,
                        roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.ngon(shapes_orig, pos, length, rotate, thickness, np, roundness, invert, scale, xscale, yscale))

        def triangle(self, pos=[0,0], length=1, rotate=0, thickness=0,
                        roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.triangle(shapes_orig, pos, length, rotate, thickness, roundness, invert, scale, xscale, yscale))

        def pentagon(self, pos=[0,0], length=1, rotate=0, thickness=0,
                        roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.pentagon(self, pos, length, rotate, thickness, roundness, invert, scale, xscale, yscale))

        def hexagon(self, pos=[0,0], length=1, rotate=0, thickness=0,
                        roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.hexagon(shapes_orig, pos, length, rotate, thickness, roundness, invert, scale, xscale, yscale))

        def octagon(self, pos=[0,0], length=1, rotate=0, thickness=0,
                        roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.octagon(shapes_orig, pos, length, rotate, thickness, roundness, invert, scale, xscale, yscale))

        def star(self, pos=[0,0], rotate=0, thickness=0, radius=1, n=5, iradius=None,
                        roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.star(shapes_orig, pos, rotate, thickness, radius, n, iradius, roundness, invert, scale, xscale, yscale))

        def points(self, pos=[], rotate=0, path=False, roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.points(shapes_orig, pos, rotate, path, roundness, invert, scale, xscale, yscale))

        def points(self, pos=[], rotate=0, path=False, roundness=0, invert=False, scale=1, xscale=1, yscale=1):
            return convertPyVecsToJSList(shape_object_orig.points(shapes_orig, pos, rotate, path, roundness, invert, scale, xscale, yscale))

        def gear(self, pos=[0,0], n=20, radius=1, phi=20, addendum=None, dedendum=None,
                    fradius=None, rotate=0, scale=1, res=1, bevel=0):
            return convertPyVecsToJSList(shape_object_orig.gear(shapes_orig, pos, n, radius, phi, addendum, dedendum, fradius, rotate, scale, res, bevel))

        def rackgear(self, pos=(0,0), n=30, radius=5., phi=20., addendum=0.4, dedendum=0.5,
                fradius=0.1, rotate=0, scale=1.0, length=10*pi, res=1, bevel=0.05, depth=(0.4+0.6+0.1)):
            return convertPyVecsToJSList(shape_object_orig.rackgear(shapes_orig, pos, n, radius, phi, addendum, dedendum, fradius, rotate, scale, length, res, bevel, depth))
        


    class path_object(path_object_orig):

        def rectangle(self, pos=vec(0,0,0), width=6, height=None, rotate=0.0, thickness=None,
                        roundness=0.0, invert=False, scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.rectangle(paths_orig, pos, width, height, rotate, thickness, roundness, invert, scale, xscale, yscale, up))

        def circle(self, pos=vec(0,0,0), radius=3, np=32, thickness=None,
                        scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.circle(paths_orig, pos, radius, np, thickness, scale, xscale, yscale, up))

        def cross(self, pos=vec(0,0,0), width=5, thickness=2, rotate=0.0,
                        roundness=0.0, invert=False, scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.cross(paths_orig, pos, width, thickness, rotate, roundness, invert, scale, xscale, yscale, up))

        def trapezoid(self, pos=vec(0,0,0), width=6, height=3, top=None, rotate=0.0, thickness=None,
                        roundness=0.0, invert=False, scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.trapezoid(paths_orig, pos, width, height, top, rotate, thickness, roundness, invert, scale, xscale, yscale, up))

        def line(self, start=vec(0,0,0), end=vec(0,0,-1), np=2):
            return convertPyVecsToJSList(path_object_orig.line(paths_orig, start, end, np))

        def arc(self, pos=vec(0,0,0), radius=3, np=32, rotate=0.0, angle1=0, angle2=pi, thickness=None,
                        scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.arc(paths_orig, pos, radius, np, rotate, angle1, angle2, thickness, scale, xscale, yscale, up))

        def ellipse(self, pos=vec(0,0,0), width=6, height=None, np=32, thickness=None,
                        scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.ellipse(paths_orig, pos, width, height, np, thickness, scale, xscale, yscale, up))                      

        def ngon(self, pos=vec(0,0,0), np=3, length=6, radius=3.0, rotate=0.0, thickness=None,
                        roundness=0.0, invert=False, scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.ngon(paths_orig, pos, np, length, radius, rotate, thickness, roundness, invert, scale, xscale, yscale, up))

        def triangle(self, pos=vec(0,0,0), np=3, length=6, rotate=0.0, thickness=None,
                        roundness=0.0, invert=False, scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.triangle(paths_orig, pos, np, length, rotate, thickness, roundness, invert, scale, xscale, yscale, up))

        def pentagon(self, pos=vec(0,0,0), np=5, length=6, rotate=0.0, thickness=None,
                        roundness=0.0, invert=False, scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.pentagon(paths_orig, pos, np, length, rotate, thickness, roundness, invert, scale, xscale, yscale, up))                      

        def hexagon(self, pos=vec(0,0,0), np=6, length=6, rotate=0.0, thickness=None,
                        roundness=0.0, invert=False, scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.hexagon(paths_orig, pos, np, length, rotate, thickness, roundness, invert, scale, xscale, yscale, up))                      

        def star(self, pos=vec(0,0,0), radius=3, n=5, iradius=None, rotate=0.0, thickness=None,
                        roundness=0.0, invert=False, scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.star(paths_orig, pos, radius, n, iradius, rotate, thickness, roundness, invert, scale, xscale, yscale, up))                      

        def pointlist(self, pos=[], rotate=0.0, thickness=None,
                        roundness=0.0, invert=False, scale=1.0, xscale=1.0, yscale=1.0, up=vec(0,1,0)):
            return convertPyVecsToJSList(path_object_orig.pointlist(paths_orig, pos, rotate, thickness, roundness, invert, scale, xscale, yscale, up))                      

    paths = path_object()
    shapes = shape_object()
